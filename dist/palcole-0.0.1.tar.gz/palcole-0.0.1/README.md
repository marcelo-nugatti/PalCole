# Módulo preparado para la Escuela.

## Instalación:
* pip3 install palcole


